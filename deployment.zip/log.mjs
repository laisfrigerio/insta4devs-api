export const logMessage = (message) => {
    console.log(message);
}